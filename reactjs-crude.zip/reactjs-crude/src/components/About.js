import React from 'react';


const About = () => {
  return (
    <div className="container">
      <h1>About</h1>
      <p>This is RKCP INFORMATION TECHNOLOGIES owned by Mr. Rajesh Upadhyay</p>
    </div>
  );
};


export default About;